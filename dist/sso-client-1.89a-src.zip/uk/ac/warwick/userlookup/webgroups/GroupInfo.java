package uk.ac.warwick.userlookup.webgroups;

public class GroupInfo {
	private int size;

	public GroupInfo(int size) {
		this.size = size;
	}
	
	public int getSize() {
		return size;
	}
}
