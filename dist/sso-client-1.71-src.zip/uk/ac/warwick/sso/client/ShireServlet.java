/*
 * Created on 11-Mar-2005
 *
 */
package uk.ac.warwick.sso.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.configuration.Configuration;
import org.apache.log4j.Logger;
import org.springframework.util.FileCopyUtils;

import uk.ac.warwick.sso.client.cache.UserCache;

/**
 * @author Kieran Shaw
 */
public class ShireServlet extends HttpServlet {
	private static final long serialVersionUID = 3043814958673574588L;

	private static final Logger LOGGER = Logger.getLogger(ShireServlet.class);

	private Configuration _config;

	private UserCache _cache;

	private String _configSuffix = "";
	
	private String getMessage = null;

	public ShireServlet() {
		super();
	}

	protected final void doGet(final HttpServletRequest req, final HttpServletResponse res) throws ServletException, IOException {
		res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
		if (getMessage == null) {
			InputStream page = getClass().getResourceAsStream("shireget.html");
			getMessage = FileCopyUtils.copyToString(new InputStreamReader(page));
		}
		res.setContentType("text/html");
		FileCopyUtils.copy(getMessage, res.getWriter());
	}

	protected final void doPost(final HttpServletRequest req, final HttpServletResponse res) throws ServletException, IOException {
		process(req, res);
	}

	/**
	 * @param req
	 * @throws IOException
	 * @throws HttpException
	 */
	private void process(final HttpServletRequest req, final HttpServletResponse res) {

		String saml64 = req.getParameter("SAMLResponse");
		String target = req.getParameter("TARGET");

		String remoteHost = req.getRemoteHost();
		if (req.getHeader("x-forwarded-for") != null) {
			remoteHost = req.getHeader("x-forwarded-for");
		}

		ShireCommand command = new ShireCommand();

		command.setRemoteHost(remoteHost);
		command.setCache(_cache);

		AttributeAuthorityResponseFetcher fetcher = new AttributeAuthorityResponseFetcherImpl(_config);
		command.setAaFetcher(fetcher);
		command.setConfig(_config);
		Cookie cookie = null;
		try {
			cookie = command.process(saml64, target);
		} catch (SSOException e) {
			LOGGER.warn("Could not generate cookie", e);
		}

		if (cookie != null) {
			LOGGER.debug("Adding SSC (" + cookie.getValue() + " ) to response");
			res.addCookie(cookie);
			LOGGER.debug("User being redirected to target with new SSC");
		} else if (getCookie(req.getCookies(), _config.getString("shire.sscookie.name")) == null) {
			LOGGER.warn("No SSC cookie returned to client, nor do they have a previous SSC");
			// if you couldn't get a service specific cookie set, then we must
			// destory the auto login cookie because it will keep redirecting
			// the user
			Cookie ltc = new Cookie("SSO-LTC", "");
			ltc.setDomain(".warwick.ac.uk");
			ltc.setPath("/");
			ltc.setMaxAge(0);
			res.addCookie(ltc);
			LOGGER.debug("User being redirected to target but they didn't get a new SSC so we are clearing the SSO-LTC");
		} else {
			LOGGER.debug("User being redirected to target but they didn't get a new SSC, so we are reusing the old one");
		}

		// Cookie policy header so that IE can accept cookies from within iframes
		res.setHeader("P3P", "CP=\"CAO PSA OUR\"");

		res.setHeader("Location", target);
		res.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);

	}

	public final void init(final ServletConfig ctx) throws ServletException {
		super.init(ctx);

		if (ctx.getInitParameter("configsuffix") != null) {
			_configSuffix = ctx.getInitParameter("configsuffix");
		}

		if (getConfig() == null) {
			_config = (Configuration) ctx.getServletContext().getAttribute(SSOConfigLoader.SSO_CONFIG_KEY + _configSuffix);
		}

		if (getCache() == null) {
			_cache = (UserCache) ctx.getServletContext().getAttribute(SSOConfigLoader.SSO_CACHE_KEY + _configSuffix);
		}

	}

	private Cookie getCookie(final Cookie[] cookies, final String name) {

		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				if (cookie.getName().equals(name)) {
					return cookie;
				}
			}
		}
		return null;
	}

	public final UserCache getCache() {
		return _cache;
	}

	public final void setCache(final UserCache cache) {
		_cache = cache;
	}

	public final Configuration getConfig() {
		return _config;
	}

	public final void setConfig(final Configuration config) {
		_config = config;
	}

	public final String getConfigSuffix() {
		return _configSuffix;
	}

	public final void setConfigSuffix(final String configSuffix) {
		_configSuffix = configSuffix;
	}

}
