/*
 * Created on 31-Mar-2005
 *
 */
package uk.ac.warwick.userlookup;



public interface WebService {
	
	void setTimeoutConfig(WebServiceTimeoutConfig config);
	

}
